#!/usr/bin/env python3
"""Fail deployment if generated Play Haus data is stale, malformed, or unusable."""
import json, pathlib, datetime, sys
from zoneinfo import ZoneInfo
root = pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '.')
today = datetime.datetime.now(ZoneInfo('America/New_York')).date()
errors=[]
def load(name):
    try: return json.loads((root/name).read_text())
    except Exception as e: errors.append(f'{name}: {e}'); return {}
data=load('data.json'); slate=load('slate.json')
for name,obj in [('data.json',data),('slate.json',slate)]:
    stamp=str(obj.get('built',''))[:10]
    if stamp!=str(today): errors.append(f'{name} built {stamp or "unknown"}, expected {today}')
for sport in ('NBA','NFL'):
    if not data.get(sport): errors.append(f'data.json missing {sport} stats')
    games=slate.get(sport,{}).get('games',[])
    upcoming=[g for g in games if str(g.get('date',''))>=str(today)]
    print(f'{sport}: {len(games)} listed games, {len(upcoming)} today/future, {sum(g.get("total") is not None for g in upcoming)} with totals')
    if not upcoming: errors.append(f'{sport}: no games today or in future (check schedule ingestion)')
if errors:
    print('FAILED data checks:'); [print(' -',e) for e in errors];sys.exit(1)
print('Data freshness and schedule checks passed. NOTE: odds coverage is informational, not guaranteed.')
